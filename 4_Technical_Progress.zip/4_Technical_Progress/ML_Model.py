import os
import pandas as pd
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense
import matplotlib.pyplot as plt

def find_max_rows(directory):
    max_rows = 0
    for root, _, files in os.walk(directory):
        for file in files:
            if file.endswith('.csv'):
                file_path = os.path.join(root, file)
                df = pd.read_csv(file_path)
                max_rows = max(max_rows, df.shape[0])
    return max_rows

def normalize_data(data):
    """Normalize data to the range [0, 1]."""
    min_val = np.min(data)
    max_val = np.max(data)
    return (data - min_val) / (max_val - min_val)

def smooth_data_moving_average(data, window_size=5):
    """Smooth data using a moving average with a trailing window."""
    smoothed_data = np.copy(data)
    num_rows = data.shape[0]
    num_columns = data.shape[1]
    
    for i in range(num_columns):
        for j in range(num_rows):
            start = max(0, j - window_size + 1)
            end = j + 1
            smoothed_data[j, i] = np.mean(data[start:end, i])
    
    return smoothed_data

def load_csv_files_from_directory(directory, max_rows):
    data = []
    labels = []
    label_map = {}
    label_index = 0
    num_files = 0

    for root, dirs, files in os.walk(directory):
        for dir_name in dirs:
            gesture_dir = os.path.join(root, dir_name)
            if dir_name not in label_map:
                label_map[dir_name] = label_index
                label_index += 1

            for file in os.listdir(gesture_dir):
                if file.endswith('.csv'):
                    file_path = os.path.join(gesture_dir, file)
                    df = pd.read_csv(file_path)
                    
                    # Drop the timestep column
                    df = df.drop(columns=['Timestep'])

                    # Convert DataFrame to numpy array
                    data_array = df.values

                    # Normalize data
                    data_array = normalize_data(data_array)

                    # Smooth data
                    data_array = smooth_data_moving_average(data_array)

                    # Pad data
                    padded_data = tf.keras.utils.pad_sequences(
                        [data_array], 
                        maxlen=max_rows, 
                        padding='post', 
                        dtype='float32'
                    )
                    
                    # Append to the data list
                    data.append(padded_data[0])
                    labels.append(label_map[dir_name])
                    
                    num_files += 1

    return np.array(data), np.array(labels), label_map, num_files

def create_tf_dataset(data, labels, batch_size=16):
    dataset = tf.data.Dataset.from_tensor_slices((data, labels))
    dataset = dataset.shuffle(buffer_size=100).batch(batch_size).prefetch(tf.data.AUTOTUNE)
    return dataset

def preprocess_and_create_dataset(base_directory):
    max_rows = find_max_rows(base_directory)
    data, labels, label_map, num_files = load_csv_files_from_directory(base_directory, max_rows)
    
    # Split the data into training and validation sets
    split_idx = int(0.6 * len(data))
    train_data, val_data = data[:split_idx], data[split_idx:]
    train_labels, val_labels = labels[:split_idx], labels[split_idx:]
    
    train_dataset = create_tf_dataset(train_data, train_labels)
    val_dataset = create_tf_dataset(val_data, val_labels)
    
    return train_dataset, val_dataset, label_map, num_files

def build_and_train_model(train_dataset, val_dataset, num_classes):
    model = Sequential([
        LSTM(16, input_shape=(None, train_dataset.element_spec[0].shape[-1]), return_sequences=True),
        LSTM(8),
        Dense(num_classes, activation='softmax')
    ])
    
    model.compile(optimizer = tf.keras.optimizers.Adam(learning_rate=1e-2),
                  loss='sparse_categorical_crossentropy',
                  metrics=['accuracy'])
    
    history = model.fit(train_dataset,
                        epochs=20,
                        validation_data=val_dataset,
                        verbose=1)
    
    return model, history

# Example usage
base_directory = "Training_Data"
train_dataset, val_dataset, label_map, num_files = preprocess_and_create_dataset(base_directory)

print("Dataset created with the following label map:", label_map)
print("Total number of CSV files processed:", num_files)

# Build and train the model
num_classes = len(label_map)
model, history = build_and_train_model(train_dataset, val_dataset, num_classes)

# Print model summary
model.summary()

# Print training history
print("Training history:", history.history)

# Evaluate the model on the validation set
val_loss, val_accuracy = model.evaluate(val_dataset)
print(f'Validation loss: {val_loss}')
print(f'Validation accuracy: {val_accuracy}')

plt.plot(history.history['accuracy'], label='accuracy')
plt.plot(history.history['val_accuracy'], label = 'val_accuracy')
plt.xlabel('Epoch')
plt.ylabel('Accuracy')
plt.ylim([0, 1])
plt.legend(loc='lower right')
plt.show()

