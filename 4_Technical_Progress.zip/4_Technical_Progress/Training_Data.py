import serial
import csv
import os
import time
import keyboard
import re
import platform

def clear_screen():
    """Clear the terminal screen."""
    if platform.system() == "Windows":
        os.system('cls')  # Command for Windows
    else:
        os.system('clear')  # Command for macOS and Linux

def scan_existing_users():
    """Scan the Training_Data directory for existing user names based on the file names."""
    base_directory = "Training_Data"
    if not os.path.exists(base_directory):
        return []

    existing_users = set()
    for gesture_dir in os.listdir(base_directory):
        gesture_path = os.path.join(base_directory, gesture_dir)
        if os.path.isdir(gesture_path):
            for file in os.listdir(gesture_path):
                if file.endswith(".csv"):
                    user_name = file.split('_')[0]  # Extract the user name from the file name
                    existing_users.add(user_name)

    return sorted(existing_users)

def get_user_name():
    clear_screen()
    existing_users = scan_existing_users()

    print("Select an existing user or enter a new user name:")
    if existing_users:
        for i, user_name in enumerate(existing_users, start=1):
            print(f"{i}: {user_name}")
        print(f"{len(existing_users) + 1}: Enter a new user name")
    else:
        print("No existing users found. Please enter a new user name.")

    while True:
        if existing_users:
            try:
                selection = int(input(f"Enter a number between 1 and {len(existing_users) + 1}: "))
                if 1 <= selection <= len(existing_users):
                    return existing_users[selection - 1]
                elif selection == len(existing_users) + 1:
                    return input("Enter the new user name: ").strip()
            except ValueError:
                pass
        else:
            return input("Enter the new user name: ").strip()

def scan_existing_gestures():
    """Scan the Training_Data directory and return a list of existing gestures."""
    base_directory = "Training_Data"
    if not os.path.exists(base_directory):
        return []
    
    existing_gestures = [name for name in os.listdir(base_directory) if os.path.isdir(os.path.join(base_directory, name))]
    return existing_gestures

def select_gesture():
    clear_screen()
    existing_gestures = scan_existing_gestures()

    print("Select an existing gesture or enter a new gesture name:")
    if existing_gestures:
        for i, gesture_name in enumerate(existing_gestures, start=1):
            print(f"{i}: {gesture_name}")
        print(f"{len(existing_gestures) + 1}: Enter a new gesture name")
    else:
        print("No existing gestures found. Please enter a new gesture name.")
    
    while True:
        if existing_gestures:
            try:
                time.sleep(0.2)
                selection = int(input(f"Enter a number between 1 and {len(existing_gestures) + 1}: "))
                if 1 <= selection <= len(existing_gestures):
                    return existing_gestures[selection - 1]
                elif selection == len(existing_gestures) + 1:
                    return input("Enter the new gesture name: ").strip()
            except ValueError:
                pass
        else:
            return input("Enter the new gesture name: ").strip()


def create_gesture_directory(gesture_name):
    base_directory = "Training_Data"
    os.makedirs(base_directory, exist_ok=True)
    
    gesture_directory = os.path.join(base_directory, gesture_name)
    os.makedirs(gesture_directory, exist_ok=True)
    
    return gesture_directory

def get_next_iteration_number(gesture_directory, user_name, gesture_name):
    files = os.listdir(gesture_directory)
    iteration = 0
    for file in files:
        if file.startswith(f"{user_name}_{gesture_name}_"):
            try:
                existing_iteration = int(file.split('_')[-1].split('.')[0])
                iteration = max(iteration, existing_iteration + 1)
            except ValueError:
                continue
    return iteration

def capture_data(serial_port, gesture_directory, user_name):
    clear_screen()
    gesture_name = os.path.basename(gesture_directory)
    iteration = get_next_iteration_number(gesture_directory, user_name, gesture_name)
    fieldnames = ["Timestep", "R_flex_thumb", "R_flex_pointer", "R_flex_middle", "R_flex_ring", "R_flex_pinkie"]
    COUNTER = 0

    csv_filename = os.path.join(gesture_directory, f"{user_name}_{gesture_name}_{iteration}.csv")

    # Open the CSV file and initialize the CSV writer
    with open(csv_filename, mode='w', newline='') as csv_file:
        csv_writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
        csv_writer.writeheader()

        print("Press 'enter' to start recording...")
        time.sleep(0.2)
        while not keyboard.is_pressed("enter"):
            time.sleep(0.1)
        print("Recording started... Press 'enter' again to stop.")
        time.sleep(0.5)

        ser = serial.Serial(serial_port, 9600)
        ser.flushInput()

        recording = True
        while recording:
            try:
                line = ser.readline().decode('utf-8').strip()
                if line:
                    data = line.split()
                    if len(data) == 5:
                        try:
                            flex1, flex2, flex3, flex4, flex5 = map(float, data)

                            # Write to CSV within the 'with' block
                            csv_writer.writerow({
                                "R_flex_thumb": flex1,
                                "R_flex_pointer": flex2,
                                "R_flex_middle": flex3,
                                "R_flex_ring": flex4,
                                "R_flex_pinkie": flex5,
                                "Timestep": COUNTER
                            })
                            print(f"Sample {COUNTER} captured: {flex1}, {flex2}, {flex3}, {flex4}, {flex5}")
                            COUNTER += 1
                        except ValueError:
                            print("Data conversion error. Skipping this line.")
                            continue  # Skip the current line and continue the loop
                    else:
                        print("Incomplete data received. Skipping this line.")
                else:
                    print("Empty line received. Skipping this line.")
                    continue
            except UnicodeDecodeError as e:
                print(f"UnicodeDecodeError: {e} - Ignoring this line and continuing.")
                continue  # Skip the current line and continue the loop
            except Exception as e:
                print(f"Error: {e} - Ignoring this line and continuing.")
                continue  # Skip the current line and continue the loop

            if keyboard.is_pressed("enter"):
                print("Recording stopped.")
                time.sleep(0.2)  # Debounce delay to avoid multiple detections
                recording = False

        ser.close()
    print(f"Data saved to {csv_filename}")


def ask_to_record_another():
    clear_screen()
    print("Press 'Enter' to record the same gesture again, 'C' to change gesture, or 'Esc' to exit.")
    while True:
        if keyboard.is_pressed("enter"):
            print("Recording the same gesture again...")
            time.sleep(0.5)
            return 'same'
        elif keyboard.is_pressed("c"):
            print("Changing gesture...")
            time.sleep(0.5)
            return 'change'
        elif keyboard.is_pressed("esc"):
            time.sleep(0.5)
            print("Exiting...")
            return 'exit'
        time.sleep(0.1)  # Small delay to avoid excessive CPU usage

def main():
    user_name = get_user_name()
    while True:
        gesture_name = select_gesture()
        while True:
            gesture_directory = create_gesture_directory(gesture_name)
            
            # Replace 'COM9' with your correct serial port if needed
            serial_port = 'COM9'
            
            capture_data(serial_port, gesture_directory, user_name)
            
            action = ask_to_record_another()
            if action == 'same':
                continue  # Continue with the same gesture
            elif action == 'change':
                break  # Break the inner loop to select a new gesture
            elif action == 'exit':
                return  # Exit the program

if __name__ == "__main__":
    main()

