import os
import pandas as pd

def delete_small_csv_files(directory):
    for root, _, files in os.walk(directory):
        for file in files:
            if file.endswith('.csv'):
                file_path = os.path.join(root, file)
                try:
                    # Read the CSV file
                    df = pd.read_csv(file_path)
                    # Check if the number of rows is less than 2
                    if len(df) < 5:
                        print(f"Deleting file: {file_path}")
                        #os.remove(file_path)
                except Exception as e:
                    print(f"Error processing file {file_path}: {e}")

# Replace with your directory path
directory_path = 'Training_data'
delete_small_csv_files(directory_path)
