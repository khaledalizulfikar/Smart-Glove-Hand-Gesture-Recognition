import os
import pandas as pd

# Define the path to your main directory containing subdirectories
main_directory = r'C:\Users\khaled\OneDrive\Thesis\4_Technical_Progress\Training_Data'

# Initialize an empty list to store DataFrames
dataframes = []

# Loop through each subdirectory in the main directory
for gesture in os.listdir(main_directory):
    gesture_dir = os.path.join(main_directory, gesture)
    
    if os.path.isdir(gesture_dir):
        # Loop through each CSV file in the subdirectory
        for csv_file in os.listdir(gesture_dir):
            if csv_file.endswith('.csv'):
                file_path = os.path.join(gesture_dir, csv_file)
                
                # Read the CSV file into a DataFrame
                df = pd.read_csv(file_path)
                
                # Add a 'gesture' column with the gesture name
                df['gesture'] = gesture
                
                # Append the DataFrame to the list
                dataframes.append(df)

# Concatenate all DataFrames into a single DataFrame
combined_df = pd.concat(dataframes, ignore_index=True)

# Save the combined DataFrame to a new CSV file
combined_df.to_csv(r'C:\Users\khaled\OneDrive\Thesis\4_Technical_Progress\Training_Data\combined_data.csv', index=False)
