import numpy as np
import tensorflow as tf
import serial
import time
import pandas as pd
from sklearn.preprocessing import LabelEncoder

# Load the trained model
model_path = r'C:\Users\khaled\OneDrive\Thesis\4_Technical_Progress\MLModel.keras'
model = tf.keras.models.load_model(model_path)
combined_csv_path = r'C:\Users\khaled\OneDrive\Thesis\4_Technical_Progress\Training_Data\combined_data.csv'

bluetooth_port = 'COM13'
baud_rate = 9600 
timeout = 10

# Get the gesture names
df = pd.read_csv(combined_csv_path)
labels = df['gesture']
labels_array = labels.to_numpy()
labels_unique = np.unique(labels_array)
print(labels_unique)

# Initialize the serial port
ser = serial.Serial(bluetooth_port, baud_rate, timeout=timeout)
print(f"Connected to {bluetooth_port} at {baud_rate} baud rate.")

def preprocess_data(data):
    # Convert list of strings to float32
    data = np.array(data, dtype=np.float32)
    
    # Ensure the data array has exactly 5 elements
    if len(data) != 5:
        raise ValueError(f'Expected 5 features, but got {len(data)}')

    # Reshape data to match model input shape (1, 5)
    data = np.reshape(data, (1, -1))
    return data  # Make sure to return the processed data

def main():
    try:
        while True:
            # Read data from the serial port
            line = ser.readline().decode('utf-8').strip()
            if line:
                # Split the line into a list of strings
                data = line.split()
                
                # Check if we have the right amount of data
                if len(data) == 5:
                    preprocessed_data = preprocess_data(data)
                    # Make prediction
                    prediction = model.predict(preprocessed_data)
                    predicted_class = np.argmax(prediction, axis=-1)
                    predicted_gesture = labels_unique[predicted_class[0]]
                    
                    print(f'Predicted Class: {predicted_class[0]}')
                    print(f'Predicted Gesture: {predicted_gesture}')
                else:
                    print('Error: Received data does not have 5 elements.')
            
            # Sleep briefly to avoid overwhelming the serial port
            time.sleep(0.1)  # Adjust sleep time as needed
            
    except KeyboardInterrupt:
        print("Interrupted by user.")
    
    except Exception as e:
        print(f'Error: {e}')
    
    finally:
        ser.close()
        print("Connection closed.")

if __name__ == "__main__":
    main()
