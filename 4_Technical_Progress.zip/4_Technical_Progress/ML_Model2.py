import pandas as pd
import numpy as np
import tensorflow as tf
from tensorflow.keras import layers, models
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay
from tensorflow.keras.callbacks import EarlyStopping
import platform
import os

def clear_screen():
    """Clear the terminal screen."""
    if platform.system() == "Windows":
        os.system('cls')  # Command for Windows
    else:
        os.system('clear')  # Command for macOS and Linux
        
# Path to the combined CSV file
combined_csv_path = r'C:\Users\khaled\OneDrive\Thesis\4_Technical_Progress\Training_Data\combined_data.csv'
finger_touching_csv_path = r'C:\Users\khaled\OneDrive\Thesis\4_Technical_Progress\Training_Data\finger_touching.csv'
nine_gestures_csv_path = r'C:\Users\khaled\OneDrive\Thesis\4_Technical_Progress\Training_Data\nine_gestures.csv'

# Load the combined CSV file into a DataFrame
df = pd.read_csv(combined_csv_path)

clear_screen()
print("Select an option:")
print("1: Data without 'finger_touching'")
print("2: Data with 'finger_touching'")

# Get user input
choice = input("Enter the number of your choice (1 or 2): ")

if choice == '1':
    # Exclude rows where the 'gesture' column contains the phrase 'finger_touching'
    df_filtered = df[~df['gesture'].str.contains('finger_touching', case=False, na=False)]
    df_filtered.to_csv(nine_gestures_csv_path, index=False)
elif choice == '2':
    # Include only rows where the 'gesture' column contains the phrase 'finger_touching'
    df_filtered = df[df['gesture'].str.contains('finger_touching', case=False, na=False)]
    df_filtered.to_csv(finger_touching_csv_path, index=False)
else:
    print("Invalid choice. Exiting the program.")
    exit()


# Separate features (excluding the 'gesture' column) and labels (the 'gesture' column)
features = df_filtered.drop(columns=['gesture', 'Timestep'])
labels = df_filtered['gesture']

# Convert features and labels to NumPy arrays
features_array = features.to_numpy()
labels_array = labels.to_numpy()
print(np.shape(features_array))
# Initialize the LabelEncoder
label_encoder = LabelEncoder()
# Fit and transform the gesture labels to integers
labels_encoded = label_encoder.fit_transform(labels_array)

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(features_array, labels_encoded, test_size=0.2, random_state=42)

print(X_test[:5])

print(X_test[:5])

# Define the model
model = models.Sequential()

# Add a normalization layer to normalize the feature data
normalization_layer = layers.Normalization()
normalization_layer.adapt(X_train)  # Fit normalization layer on training data
model.add(layers.InputLayer(shape=(features_array.shape[1],)))
model.add(normalization_layer)  # Add the normalization layer to the model

model.add(layers.Dense(128, activation='relu'))
model.add(layers.Dropout(0.5))
model.add(layers.Dense(64, activation='relu'))
model.add(layers.Dropout(0.5))
model.add(layers.Dense(32, activation='relu'))
model.add(layers.Dense(len(np.unique(labels_encoded)), activation='softmax'))

# Compile the model
model.compile(tf.keras.optimizers.RMSprop(learning_rate=1e-3),
              loss='sparse_categorical_crossentropy',
              metrics=['accuracy'])

# Summary of the model
model.summary()

early_stopping = EarlyStopping(monitor='val_accuracy', patience=10, restore_best_weights=True)
# Fit the model

history = model.fit(X_train, y_train, epochs=100, validation_split=0.2, batch_size=32, verbose=1, callbacks=[early_stopping])

# Evaluate the model on the test set
test_loss, test_accuracy = model.evaluate(X_test, y_test, verbose=1)
print(f'Test loss: {test_loss}')
print(f'Test accuracy: {test_accuracy}')


import matplotlib.pyplot as plt

# Plot training & validation accuracy values
plt.figure(figsize=(14, 6))

plt.subplot(1, 2, 1)
plt.plot(history.history['accuracy'])
plt.plot(history.history['val_accuracy'])
plt.title('Model Accuracy')
plt.xlabel('Epoch')
plt.ylabel('Accuracy')
plt.legend(['Train', 'Validation'], loc='upper left')

# Plot training & validation loss values
plt.subplot(1, 2, 2)
plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.title('Model Loss')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.legend(['Train', 'Validation'], loc='upper left')

plt.show()

# Print test accuracy
print(f'Test accuracy: {test_accuracy:.4f}')
print(f'Test loss: {test_loss:.4f}')

# Predict the labels on the test set
y_pred = np.argmax(model.predict(X_test), axis=-1)

# Generate confusion matrix
cm = confusion_matrix(y_test, y_pred)

# Display confusion matrix
disp = ConfusionMatrixDisplay(confusion_matrix=cm,
                              display_labels=label_encoder.classes_)
disp.plot(cmap=plt.cm.Blues)
plt.show()

# Define the path where you want to save the model
if choice == '1':
    model_save_path = r'C:\Users\khaled\OneDrive\Thesis\4_Technical_Progress\nine_gestures.keras'
elif choice == '2':
    model_save_path = r'C:\Users\khaled\OneDrive\Thesis\4_Technical_Progress\finger_touching.keras'
else:
    print("Invalid choice. Exiting the program.")
    exit()

# Save the model
model.save(model_save_path)
print(f'Model saved to {model_save_path}')