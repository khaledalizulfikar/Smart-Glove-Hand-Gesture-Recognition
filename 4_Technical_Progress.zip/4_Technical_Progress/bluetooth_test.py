import serial

bluetooth_port = 'COM13'
baud_rate = 9600 
timeout = 10

try:
    # Establish a connection to the Bluetooth serial module
    ser = serial.Serial(bluetooth_port, baud_rate, timeout=timeout)
    print(f"Connected to {bluetooth_port} at {baud_rate} baud rate.")

    # Variable to store the incoming serial messages
    serial_messages = []

    while True:
        # Read data from the serial port
        message = ser.readline().decode('utf-8').strip()

        if message:
            print(f"Received: {message}")
            serial_messages.append(message)


except serial.SerialException as e:
    print(f"Error: {e}")
finally:
    # Close the serial connection
    ser.close()
    print("Connection closed.")

# Now serial_messages contains all received messages
